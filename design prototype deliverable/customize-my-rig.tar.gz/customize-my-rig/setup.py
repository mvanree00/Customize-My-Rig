from setuptools import setup

setup(
    name='Customize My Rig',
    version='0.1',
    packages=['customize-my-rig',],
    description='Automatic PC Creator',
    install_requires=['Django','requests','bs4'],
)