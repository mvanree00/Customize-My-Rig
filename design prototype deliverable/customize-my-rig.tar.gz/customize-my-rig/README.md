# Customize-My-Rig
https://github.com/mvanree00/Customize-My-Rig

1. Activate, or create and activate, a virtual environment.

Activation:
source /path/to/venv/bin/activate
Creation:
python3 -m venv newenv
source newenv/bin/activate

2. Place .tar.gz file and .py file in the same folder

2. Setup Customize My Rig!
./run_me

3. Customize your PC!
Open your browser and navigate to http://127.0.0.1:8000/